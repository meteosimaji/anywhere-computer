"""Credential values remain in the OS credential store, never config or arguments."""

import hashlib
import secrets
import sys
from pathlib import Path

import keyring
from keyring.backend import KeyringBackend
from keyring.backends.chainer import ChainerBackend
from keyring.errors import KeyringError, PasswordSetError

SERVICE = "Anywhere Computer"


def _macos_update_password(service: str, account: str, value: str) -> None:
    """Update an existing Keychain item without changing its owner or ACL.

    keyring 25.7.0 replaces an item with delete/add. On macOS, deletion can
    fail with errSecInvalidOwnerEdit when another trusted app has accessed the
    item, even though updating its value is allowed.
    """
    import ctypes
    from ctypes.util import find_library

    from keyring.backends.macOS import api

    security = ctypes.CDLL(find_library("Security"))
    core_foundation = ctypes.CDLL(find_library("CoreFoundation"))
    update = security.SecItemUpdate
    update.restype = ctypes.c_int32
    update.argtypes = (ctypes.c_void_p, ctypes.c_void_p)
    data_create = core_foundation.CFDataCreate
    data_create.restype = ctypes.c_void_p
    data_create.argtypes = (ctypes.c_void_p, ctypes.c_void_p, ctypes.c_long)
    release = core_foundation.CFRelease
    release.restype = None
    release.argtypes = (ctypes.c_void_p,)

    encoded = value.encode("utf-8")
    buffer = ctypes.create_string_buffer(encoded)
    data = data_create(None, buffer, len(encoded))
    if not data:
        raise PasswordSetError("Could not prepare Keychain update")
    try:
        query = api.create_query(  # type: ignore[no-untyped-call]
            kSecClass=api.k_("kSecClassGenericPassword"),  # type: ignore[no-untyped-call]
            kSecAttrService=service,
            kSecAttrAccount=account,
        )
        attributes = api.create_query(  # type: ignore[no-untyped-call]
            kSecValueData=ctypes.c_void_p(data)
        )
        try:
            status = update(query, attributes)
        finally:
            release(attributes)
            release(query)
    finally:
        release(data)
    if status:
        raise PasswordSetError(f"Could not update Keychain item (OSStatus {status})")


class _UpdatingMacOSKeyring(KeyringBackend):
    """Keep the native keyring's reads/adds; update existing items in place."""

    priority = 1

    def __init__(self, backend: KeyringBackend) -> None:
        self.backend = backend

    def get_password(self, service: str, account: str) -> str | None:
        return self.backend.get_password(service, account)

    def set_password(self, service: str, account: str, value: str) -> None:
        if self.backend.get_password(service, account) is None:
            self.backend.set_password(service, account, value)
        else:
            _macos_update_password(service, account, value)

    def delete_password(self, service: str, account: str) -> None:
        self.backend.delete_password(service, account)


def has_interactive_input() -> bool:
    """Windows NUL is a character device, but is not a console for hidden input."""
    if not sys.stdin.isatty():
        return False
    if sys.platform == "win32":
        import ctypes
        import msvcrt
        from ctypes import wintypes

        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GetConsoleMode.argtypes = [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)]
        kernel.GetConsoleMode.restype = wintypes.BOOL
        mode = wintypes.DWORD()
        try:
            handle = msvcrt.get_osfhandle(sys.stdin.fileno())
            return bool(kernel.GetConsoleMode(handle, ctypes.byref(mode)))
        except (OSError, ValueError):
            return False
    return True


def secure_backend() -> KeyringBackend:
    """Select a native OS credential store; never fall back to plaintext."""
    backend = keyring.get_keyring()
    secure_modules = (
        "keyring.backends.macOS",
        "keyring.backends.Windows",
        "keyring.backends.SecretService",
        "keyring.backends.kwallet",
    )
    if isinstance(backend, ChainerBackend):
        candidates = [
            candidate
            for candidate in backend.backends
            if type(candidate).__module__.startswith(secure_modules)
        ]
        if not candidates:
            raise RuntimeError("No OS credential store is available")
        backend = candidates[0]
    # Refuse third-party file-backed implementations, even if selected by the environment.
    module = type(backend).__module__
    if not module.startswith(secure_modules):
        raise RuntimeError("An OS credential store is required; plaintext stores are unsupported")
    if module.startswith("keyring.backends.macOS"):
        return _UpdatingMacOSKeyring(backend)
    return backend


def local_credential(directory: Path, *, create: bool = False) -> str:
    account = "local-agent-" + hashlib.sha256(str(directory.resolve()).encode()).hexdigest()[:24]
    try:
        backend = secure_backend()
        credential = backend.get_password(SERVICE, account)
        if credential is None and create:
            credential = secrets.token_urlsafe(32)
            backend.set_password(SERVICE, account, credential)
        if credential is None:
            raise RuntimeError("Agent is not initialized. Run: anywhere start")
        return credential
    except KeyringError as error:
        raise RuntimeError(
            "OS credential store is unavailable; unlock it and run anywhere doctor"
        ) from error
    except Exception as error:
        # keyring's Windows backend exposes pywin32-ctypes errors directly;
        # that optional Windows dependency does not derive from KeyringError.
        # Keep every other failure unchanged, including programming errors.
        error_type = type(error)
        if (sys.platform == "win32"
                and error_type.__module__ == "win32ctypes.pywin32.pywintypes"
                and error_type.__name__ == "error"
                and getattr(error, "winerror", None) == 1312):
            raise RuntimeError(
                "Windows Credential Manager is unavailable in this logon session "
                "(WinError 1312). Run the agent and connector in an interactive "
                "Windows logon, or use a configured authenticated HTTPS connector. "
                "Starting the agent alone does not grant an SSH logon access to its credentials."
            ) from None
        raise
