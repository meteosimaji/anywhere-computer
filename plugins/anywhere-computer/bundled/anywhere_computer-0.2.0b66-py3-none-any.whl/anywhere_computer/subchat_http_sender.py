"""One-shot localhost generation transport for an unintegrated HTTP sender.

This exercises reservation, HTTP streaming and candidate checkpointing without
claiming that ChatGPT accepts an independently prepared generation request.
No production endpoint, credential discovery or browser fallback is provided.
"""
from __future__ import annotations

import json
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Literal
from urllib.parse import urlsplit

from .subchat import SubchatAccessError, SubchatOutcomeUnknown
from .subchat_sse import SSEDecoder
from .subchat_state import SubchatAccountMismatch, SubchatSubmission, SubchatSubmissions

CONVERSATION_ID = re.compile(r'[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\Z')


@dataclass(frozen=True)
class HTTPFollowupParent:
    """A caller's explicit branch observation; this module cannot discover it."""

    conversation_id: str
    last_user_message_id: str
    parent_message_id: str
    source: Literal['verified_history'] = 'verified_history'


@dataclass(frozen=True)
class HTTPGenerationPlan:
    """The exact identity and input already committed before dispatch."""

    operation_id: str
    account_id: str
    user_message_id: str
    prompt: str
    model_slug: str
    thinking_effort: str | None
    conversation_id: str | None
    predecessor_id: str | None

    @classmethod
    def from_reserved(cls, submission: SubchatSubmission, *,
                      followup_parent: HTTPFollowupParent | None = None) -> HTTPGenerationPlan:
        if (submission.state != 'sending' or submission.user_message_id is None
                or submission.provider_account_id is None or submission.http_selection is None):
            raise ValueError('An exact HTTP input, account and selection must be reserved')
        if submission.resources is not None:
            raise ValueError('HTTP generation resources are not implemented')
        conversation = submission.requested_conversation_id
        expected_user = submission.expected_last_user_message_id
        if (conversation is None) != (expected_user is None):
            raise ValueError('Follow-up conversation and predecessor must be paired')
        if conversation is None and followup_parent is not None:
            raise ValueError('New Chat cannot have a follow-up parent')
        if conversation is not None:
            if (followup_parent is None or followup_parent.source != 'verified_history'
                    or followup_parent.conversation_id != conversation
                    or followup_parent.last_user_message_id != expected_user
                    or not followup_parent.parent_message_id.strip()
                    or len(followup_parent.parent_message_id) > 256
                    or followup_parent.parent_message_id == expected_user
                    or followup_parent.parent_message_id == submission.user_message_id):
                raise ValueError('A matching history-verified branch parent is required')
        return cls(submission.operation_id, submission.provider_account_id,
                   submission.user_message_id, submission.prompt,
                   submission.http_selection.model_slug,
                   submission.http_selection.thinking_effort,
                   conversation,
                   followup_parent.parent_message_id if followup_parent else None)

    def body(self) -> bytes:
        # This local fixture shape is not a claim about the provider's current
        # request-specific preparation or accepted generation schema.
        body = {
            'action': 'next',
            'messages': [{'id': self.user_message_id, 'author': {'role': 'user'},
                          'content': {'content_type': 'text', 'parts': [self.prompt]},
                          'metadata': {}}],
            'model': self.model_slug, 'thinking_effort': self.thinking_effort,
        }
        if self.conversation_id is not None:
            body['conversation_id'] = self.conversation_id
            body['parent_message_id'] = self.predecessor_id
        return json.dumps(body, ensure_ascii=False, separators=(',', ':')).encode('utf-8')


@dataclass(frozen=True)
class HTTPStreamObservation:
    """Transport evidence only; never a verified receipt or final answer."""

    conversation_id: str | None
    event_count: int
    done_marker: bool


def _localhost_url(url: str) -> None:
    parsed = urlsplit(url)
    if (parsed.scheme != 'http' or parsed.hostname != '127.0.0.1'
            or parsed.port is None or parsed.username is not None
            or parsed.password is not None or parsed.fragment or parsed.query
            or parsed.path != '/backend-api/f/conversation'):
        raise ValueError('Only the exact loopback generation test path is supported')


async def post_once(plan: HTTPGenerationPlan, *, store: SubchatSubmissions,
                    owner: str | None, url: str, account_id: str,
                    on_conversation: Callable[[str], None],
                    on_rejection: Callable[[int], None]) -> HTTPStreamObservation:
    """Dispatch one POST and checkpoint consistent conversation candidates.

    The durable claim commits before the POST and is never released, even if the
    process stops before network I/O. A second caller must recover the original
    operation. The claim checks the saved completed parent; the caller must also
    verify the provider's current branch immediately before this call. This
    localhost-only fixture is not evidence of provider acceptance. Checkpoint
    callbacks remain synchronous.
    """
    _localhost_url(url)
    if plan.account_id != account_id:
        raise SubchatAccountMismatch('Reserved HTTP account changed')
    body = plan.body()
    if not store.claim_http_dispatch(
            plan.operation_id, owner=owner, user_message_id=plan.user_message_id,
            provider_account_id=account_id, prompt=plan.prompt,
            model_slug=plan.model_slug, thinking_effort=plan.thinking_effort,
            conversation_id=plan.conversation_id, predecessor_id=plan.predecessor_id):
        raise SubchatOutcomeUnknown(plan.operation_id)
    # Kept out of normal runtime dependencies until a real provider contract is
    # established. This module is not imported by the production HTTP backend.
    import httpx

    candidate = plan.conversation_id
    decoder = SSEDecoder()
    done = False
    async with httpx.AsyncClient(transport=httpx.AsyncHTTPTransport(retries=0),
                                 follow_redirects=False, trust_env=False,
                                 timeout=httpx.Timeout(120.0, connect=10.0)) as client:
        async with client.stream('POST', url, content=body, headers={
                'content-type': 'application/json', 'accept': 'text/event-stream',
                'chatgpt-account-id': account_id}) as response:
            if response.status_code in (401, 403):
                on_rejection(response.status_code)
                raise SubchatAccessError(response.status_code)
            if response.status_code != 200:
                raise ConnectionError('Generation HTTP status was not successful')
            if response.headers.get('content-type', '').split(';', 1)[0].strip() != (
                    'text/event-stream'):
                raise ValueError('Unexpected generation response format')
            async for chunk in response.aiter_bytes():
                for event in decoder.feed(chunk):
                    if event.data == '[DONE]':
                        done = True
                        continue
                    data = json.loads(event.data)
                    if not isinstance(data, dict):
                        raise ValueError('Invalid generation event shape')
                    observed = data.get('conversation_id')
                    if observed is None:
                        continue
                    if (not isinstance(observed, str)
                            or CONVERSATION_ID.fullmatch(observed) is None):
                        raise ValueError('Invalid conversation candidate')
                    if candidate is not None and candidate != observed:
                        raise ValueError('Conflicting conversation candidates')
                    if candidate is None:
                        on_conversation(observed)
                        candidate = observed
            decoder.finish()
    return HTTPStreamObservation(candidate, decoder.event_count, done)
