"""Anywhere Computer: independently implemented computer tools."""

__version__ = "0.2.0a16"
