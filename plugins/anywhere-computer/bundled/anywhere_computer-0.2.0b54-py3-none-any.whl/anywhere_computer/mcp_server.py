"""Small MCP stdio implementation; the SDK is used only for interoperability tests."""

import asyncio
import copy
import json
import re
import sys
import uuid
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import BinaryIO, cast

from pydantic import JsonValue

from . import __version__
from .connection import WIRE_LIMIT, ensure_agent, exchange
from .mcp_result_data import media_result_data
from .models import Reply, Request
from .plugin_audio import audio_summary
from .plugin_images import image_summary
from .workspace_ui import UI_ACTIONS, supports_ui, with_ui_metadata, workspace_resource

Catalog = Callable[[], Awaitable[list[JsonValue]]]
Execute = Callable[[Request], Awaitable[Reply]]
PROTOCOL_VERSION = "2025-11-25"
LOG_LEVELS = ('debug', 'info', 'notice', 'warning', 'error', 'critical',
              'alert', 'emergency')
OPERATION_CAPABILITY = "io.github.meteosimaji.anywhere-computer"
OPERATION_META = OPERATION_CAPABILITY + "/operation_id"
REQUEST_ID_ARGUMENT = "request_id"
REQUEST_ID_SCHEMA: dict[str, JsonValue] = {
    "type": "string", "pattern": "^[a-f0-9]{32}$",
    "description": "Generate a fresh 32-character lowercase hexadecimal ID (UUID hex, no hyphens) "
    "before sending to recover even a lost first response. "
    "Use the same ID only for the identical call. Poll operations_get with this ID.",
}
INSTRUCTIONS = (
    "Check computer_status before operating. Use absolute paths. Existing writes require "
    "the SHA-256 from a recent read. Terminal sessions survive this connection. After a "
    "lost response, inspect the operation ID rather than repeating a write. "
    "For recoverable calls, choose a 32-character lowercase hex request_id before sending, "
    "pass it as a normal tool argument, and use it with operations_get. A running reply is "
    "an acknowledgement; poll operations_get for completion. Recover through the original "
    "device and authorization grant (reconnection is allowed); local and other grants "
    "have separate operation scopes. An unknown ID on another connection is not evidence "
    "that the original action did not run."
)


def with_request_id(tools: list[JsonValue]) -> list[JsonValue]:
    result = copy.deepcopy(tools)
    for tool in result:
        if not isinstance(tool, dict) or not isinstance(tool.get("inputSchema"), dict):
            continue
        schema = cast(dict[str, JsonValue], tool["inputSchema"])
        properties = schema.setdefault("properties", {})
        if not isinstance(properties, dict):
            raise ValueError("Tool schema conflicts with the transport request_id argument")
        if (REQUEST_ID_ARGUMENT in properties
                and properties[REQUEST_ID_ARGUMENT] != REQUEST_ID_SCHEMA):
            raise ValueError("Tool schema conflicts with the transport request_id argument")
        properties[REQUEST_ID_ARGUMENT] = dict(REQUEST_ID_SCHEMA)
    return result


def rpc_error(identity: JsonValue, code: int, message: str) -> dict[str, JsonValue]:
    return {"jsonrpc": "2.0", "id": identity, "error": {"code": code, "message": message}}


def _reply_result(name: str, reply: Reply) -> dict[str, JsonValue]:
    structured = cast(dict[str, JsonValue], reply.model_dump(mode="json"))
    media: list[JsonValue] = []
    data, recovered = media_result_data(name, structured)
    if data is not None:
        content = data.get("content")
        if isinstance(content, list):
            projected: list[JsonValue] = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "image":
                    media.append(item)
                    projected.append(image_summary(item))
                elif isinstance(item, dict) and item.get("type") == "audio":
                    media.append(item)
                    projected.append(audio_summary(item))
                else:
                    projected.append(item)
            data["content"] = projected
            def summarize_duplicate(value: JsonValue) -> JsonValue:
                if isinstance(value, dict):
                    for item in media:
                        if (isinstance(item, dict) and value.get('type') == item.get('type')
                                and value.get('data') == item.get('data')
                                and value.get('mimeType') == item.get('mimeType')):
                            return (image_summary(item) if item['type'] == 'image'
                                    else audio_summary(item))
                    return {key: summarize_duplicate(item) for key, item in value.items()}
                if isinstance(value, list):
                    return [summarize_duplicate(item) for item in value]
                return value

            if media and 'structured_content' in data:
                data['structured_content'] = summarize_duplicate(data['structured_content'])
    # Only the wire representation changes; the durable reply retains original media bytes.
    return {
        "content": [{"type": "text", "text": json.dumps(
            structured, ensure_ascii=False, separators=(",", ":"), allow_nan=False,
        )}, *media],
        "structuredContent": structured,
        "isError": (
            reply.state not in {"completed", "running"}
            or (not recovered and data is not None and data.get("is_error") is True)
        ),
    }


class MCPSession:
    """Transport-independent MCP session with negotiated, packaged UI resources."""

    def __init__(self, catalog: Catalog, execute: Execute, *,
                 instructions: str = INSTRUCTIONS) -> None:
        self.instructions = instructions
        self.catalog = catalog
        self.execute = execute
        self.initialized = False
        self.ready = False
        self.ui_enabled = False
        self.logging_level = 'info'

    async def handle(self, packet: JsonValue) -> dict[str, JsonValue] | None:
        if not isinstance(packet, dict):
            return rpc_error(None, -32600, "Expected one JSON-RPC message")
        identity = packet.get("id")
        notification = "id" not in packet
        if packet.get("jsonrpc") != "2.0" or not isinstance(packet.get("method"), str):
            return rpc_error(None, -32600, "Invalid JSON-RPC request")
        if not notification and (
            isinstance(identity, bool) or not isinstance(identity, (str, int))
        ):
            return rpc_error(None, -32600, "Invalid request ID")
        method = packet["method"]
        params = packet.get("params", {})
        if not isinstance(params, dict):
            return None if notification else rpc_error(identity, -32602, "Invalid parameters")
        if notification:
            if method == "notifications/initialized" and self.initialized:
                self.ready = True
            # Cancellation of an observer does not stop durable work. Explicit terminal_stop
            # and search_stop tools control the underlying activities.
            return None
        result: dict[str, JsonValue]
        if method == "ping":
            result = {}
        elif method == "initialize":
            if self.initialized:
                return rpc_error(identity, -32600, "Session is already initialized")
            if (
                not isinstance(params.get("protocolVersion"), str)
                or not isinstance(params.get("capabilities"), dict)
                or not isinstance(params.get("clientInfo"), dict)
            ):
                return rpc_error(identity, -32602, "Invalid initialization parameters")
            self.initialized = True
            self.ui_enabled = supports_ui(cast(dict[str, JsonValue], params["capabilities"]))
            result = {
                "protocolVersion": PROTOCOL_VERSION,
                "capabilities": {
                    "tools": {"listChanged": False},
                    "experimental": {OPERATION_CAPABILITY: {"operationId": True}},
                },
                "serverInfo": {"name": "anywhere-computer", "version": __version__},
                "instructions": self.instructions,
            }
            if self.ui_enabled:
                capabilities = cast(dict[str, JsonValue], result["capabilities"])
                capabilities["resources"] = {"subscribe": False, "listChanged": False}
            if isinstance(getattr(self, 'notifications', None), asyncio.Queue):
                capabilities = cast(dict[str, JsonValue], result['capabilities'])
                capabilities['logging'] = {}
        elif not self.ready:
            return rpc_error(identity, -32600, "Initialize the session first")
        elif method == 'logging/setLevel':
            if not isinstance(getattr(self, 'notifications', None), asyncio.Queue):
                return rpc_error(identity, -32601, 'Method not found')
            level = params.get('level')
            if level not in LOG_LEVELS:
                return rpc_error(identity, -32602, 'Invalid logging level')
            self.logging_level = level
            result = {}
        elif method == "tools/list":
            if params.get("cursor") is not None:
                return rpc_error(identity, -32602, "No continuation cursor exists")
            result = {"tools": with_ui_metadata(
                with_request_id(await self.catalog()), enabled=self.ui_enabled,
            )}
        elif method in {"resources/list", "resources/read", "resources/templates/list"}:
            if not self.ui_enabled:
                return rpc_error(identity, -32601, "UI resources were not negotiated")
            allowed = any(isinstance(tool, dict) and tool.get("name") == "workspace_open"
                          for tool in await self.catalog())
            resource = workspace_resource()
            if method == "resources/list":
                if params.get("cursor") is not None:
                    return rpc_error(identity, -32602, "No continuation cursor exists")
                result = {"resources": [{k: v for k, v in resource.items() if k != "text"}]
                          if allowed else []}
            elif method == "resources/templates/list":
                result = {"resourceTemplates": []}
            elif not allowed or params.get("uri") != resource["uri"]:
                return rpc_error(identity, -32602, "Resource is unavailable")
            else:
                result = {"contents": [{k: v for k, v in resource.items() if k != "name"}]}
        elif method == "tools/call":
            name, arguments = params.get("name"), params.get("arguments", {})
            if not isinstance(name, str) or not isinstance(arguments, dict):
                return rpc_error(identity, -32602, "Invalid tool call")
            names = {
                item.get("name")
                for item in await self.catalog()
                if isinstance(item, dict) and isinstance(item.get("name"), str)
            }
            if name not in names:
                return rpc_error(identity, -32602, "Unknown tool")
            metadata = params.get("_meta", {})
            if not isinstance(metadata, dict):
                return rpc_error(identity, -32602, "Invalid tool metadata")
            arguments = dict(arguments)
            if REQUEST_ID_ARGUMENT in arguments and not isinstance(
                arguments[REQUEST_ID_ARGUMENT], str,
            ):
                return rpc_error(identity, -32602, "Invalid request_id")
            supplied_id = arguments.pop(REQUEST_ID_ARGUMENT, None)
            metadata_id = metadata.get(OPERATION_META)
            if OPERATION_META in metadata and (
                not isinstance(metadata_id, str)
                or re.fullmatch(r"[a-f0-9]{32}", metadata_id) is None
            ):
                return rpc_error(identity, -32602,
                                 "Invalid operation ID: expected 32 lowercase hexadecimal "
                                 "characters, without hyphens. No tool was executed.")
            if supplied_id is not None and metadata_id is not None and supplied_id != metadata_id:
                return rpc_error(identity, -32602, "Conflicting request_id and operation metadata")
            operation_id = supplied_id if supplied_id is not None else (
                metadata_id if metadata_id is not None else uuid.uuid4().hex
            )
            if (
                not isinstance(operation_id, str)
                or re.fullmatch(r"[a-f0-9]{32}", operation_id) is None
            ):
                return rpc_error(identity, -32602,
                                 "Invalid operation ID: expected 32 lowercase hexadecimal "
                                 "characters, without hyphens. No tool was executed.")
            operation = Request(operation_id=operation_id, tool=name, arguments=arguments)
            try:
                reply = await self.execute(operation)
            except (OSError, ValueError, RuntimeError, TimeoutError):
                reply = Reply(
                    operation_id=operation.operation_id,
                    state="unknown",
                    error="Connection interrupted. Query operations_get with this operation_id. "
                    "Do not repeat a write until its outcome is known.",
                )
            result = _reply_result(name, reply)
            if name == "workspace_open" and self.ui_enabled:
                result["_meta"] = {"workspaceTools": cast(list[JsonValue], sorted(
                    value for value in names if isinstance(value, str) and value in UI_ACTIONS
                ))}
        else:
            return rpc_error(identity, -32601, "Method not found")
        return {"jsonrpc": "2.0", "id": identity, "result": result}


async def serve_stdio(session: MCPSession, source: BinaryIO, destination: BinaryIO) -> None:
    write_lock = asyncio.Lock()
    tasks: set[asyncio.Task[None]] = set()
    notifications = getattr(session, 'notifications', None)

    async def pump_notifications(queue: asyncio.Queue[dict[str, JsonValue]]) -> None:
        while True:
            notice = await queue.get()
            # The negotiated 2025-11-25 stdio connection accepts server logging
            # notifications after initialization. Preserve the durable source event
            # if the client closes before this transient notice can be written.
            while not session.ready:
                await asyncio.sleep(.05)
            params = notice.get('params')
            level = params.get('level') if isinstance(params, dict) else None
            if (not isinstance(level, str) or level not in LOG_LEVELS
                    or LOG_LEVELS.index(level) < LOG_LEVELS.index(session.logging_level)):
                continue
            encoded = json.dumps(notice, ensure_ascii=False, allow_nan=False).encode() + b'\n'
            async with write_lock:
                await asyncio.to_thread(destination.write, encoded)
                await asyncio.to_thread(destination.flush)

    async def respond(line: bytes) -> None:
        response: dict[str, JsonValue] | None
        try:
            try:
                packet = json.loads(
                    line,
                    parse_constant=lambda _: (_ for _ in ()).throw(
                        ValueError("Non-finite JSON number")
                    ),
                )
            except (ValueError, UnicodeError):
                response = rpc_error(None, -32700, "Invalid JSON")
            else:
                response = await session.handle(packet)
        except Exception:
            response = rpc_error(None, -32603, "Internal error")
        if response is not None:
            encoded = json.dumps(response, ensure_ascii=False, allow_nan=False).encode() + b"\n"
            async with write_lock:
                await asyncio.to_thread(destination.write, encoded)
                await asyncio.to_thread(destination.flush)

    notification_task = (asyncio.create_task(pump_notifications(notifications))
                         if isinstance(notifications, asyncio.Queue) else None)
    try:
        while line := await asyncio.to_thread(source.readline, WIRE_LIMIT + 1):
            if len(line) > WIRE_LIMIT or not line.endswith(b"\n"):
                raise ValueError("Invalid MCP message framing or size")
            if len(tasks) >= 32:
                await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            task = asyncio.create_task(respond(line))
            tasks.add(task)
            task.add_done_callback(tasks.discard)
        if tasks:
            await asyncio.gather(*tasks)
    finally:
        if notification_task is not None:
            notification_task.cancel()
            await asyncio.gather(notification_task, return_exceptions=True)
        for task in tasks:
            task.cancel()
        await asyncio.gather(*tasks, return_exceptions=True)


async def run_mcp(directory: Path) -> None:
    from .device_router import DeviceRouter
    from .setup_connector import SetupConnector

    async def catalog() -> list[JsonValue]:
        # MCP checks the catalog before dispatch. Recover here as well as in execute,
        # or a retained connector cannot reach execute after its agent has exited.
        # This only prepares the selected agent; never retry a dispatched operation.
        await asyncio.to_thread(ensure_agent, directory, replace_idle=False)
        reply = await exchange(directory, "__catalog")
        raw = reply.data.get("tools")
        if reply.state != "completed" or not isinstance(raw, list):
            raise ValueError("Agent did not return a tool catalog")
        return raw

    async def execute(request: Request) -> Reply:
        await asyncio.to_thread(ensure_agent, directory, replace_idle=False)
        return await exchange(
            directory, request.tool, request.arguments, operation_id=request.operation_id
        )

    router = DeviceRouter(directory, catalog, execute)
    setup = SetupConnector(directory, router.catalog, router.execute)
    try:
        await serve_stdio(
            MCPSession(setup.catalog, setup.execute), sys.stdin.buffer, sys.stdout.buffer,
        )
    finally:
        setup.close()
        router.close()
