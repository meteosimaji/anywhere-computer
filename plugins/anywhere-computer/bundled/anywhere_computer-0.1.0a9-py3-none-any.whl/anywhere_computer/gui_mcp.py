"""Typed Peekaboo operations over an explicitly opened, owner-scoped MCP session."""

import asyncio
import re
import time
import uuid
from dataclasses import dataclass
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, JsonValue

from .direct_mcp import DirectMCPOutcomeUnknown
from .direct_mcp_sessions import DirectMCPSessions
from .mcp_results import normalize_tool_result
from .models import DirectMCPSessionId


def normalized(raw: dict[str, JsonValue]) -> dict[str, JsonValue]:
    try:
        return normalize_tool_result(raw)
    except ValueError:
        raise DirectMCPOutcomeUnknown('GUI result invalid after dispatch; inspect before retry') \
            from None


class GUIObserve(DirectMCPSessionId):
    window_id: int | None = Field(default=None, ge=1, le=4294967295, description=(
        'Explicit Peekaboo 4 exact-window mode. Use a window ID discovered from that '
        'server. Observes without app focus and pins actions to the returned snapshot. '
        'Requires a compatible server; never falls back to foreground input.'
    ))
    app: str = Field(min_length=1, max_length=256, description=(
        'Exact running app name accepted by the selected Peekaboo server. Names may be '
        'localized (for example 計算機). If absent, inspect its app tool and use the '
        'name returned by launch; this operation does not launch applications.'
    ))


class GUIAction(DirectMCPSessionId):
    observation_id: str = Field(pattern=r'^[a-f0-9]{32}$')


class GUIClick(GUIAction):
    element_id: str = Field(min_length=1, max_length=128)


class GUIType(GUIAction):
    text: str = Field(min_length=1, max_length=10000)
    press_return: bool = False
    element_id: str | None = Field(default=None, min_length=1, max_length=128,
        description='Optional observed input element, available in exact-window mode.')
    clear: bool = Field(default=False,
        description='Replace existing text in exact-window mode; otherwise append/type.')


class GUIKey(GUIAction):
    keys: list[str] = Field(min_length=1, max_length=8, description=(
        'One key chord, case-insensitive: cmd, shift, alt, option, ctrl, fn, a-z, 0-9, '
        'space, return (alias enter), tab, escape (alias esc), delete, '
        'arrow_up/down/left/right, f1-f12. Example: ["escape"] or ["cmd", "a"].'
    ))


class Bounds(BaseModel):
    model_config = ConfigDict(extra='ignore', allow_inf_nan=False)
    x: float
    y: float
    width: float = Field(gt=0)
    height: float = Field(gt=0)


class ImageSize(BaseModel):
    model_config = ConfigDict(extra='ignore', allow_inf_nan=False)
    width: float = Field(gt=0)
    height: float = Field(gt=0)


class CoordinateContext(BaseModel):
    model_config = ConfigDict(extra='ignore', allow_inf_nan=False)
    version: Literal[1]
    logical_space: Literal['global_display_points']
    origin: Literal['top_left']
    logical_bounds: Bounds
    delivered_image_size: ImageSize
    reference_id: str = Field(min_length=1, max_length=128)


@dataclass
class Observation:
    owner: str | None
    identity: str
    app: str
    snapshot: str
    elements: frozenset[str]
    created: float
    window_id: int | None = None


class GUIMCP:
    """One current observation per session; actions consume it before dispatch."""

    def __init__(self, sessions: DirectMCPSessions) -> None:
        self.sessions = sessions
        self.observations: dict[str, Observation] = {}
        self._interaction = asyncio.Lock()

    async def _require_exact_window(self, session_id: str, owner: str | None) -> None:
        # Check the live contract before requesting a capture. Older providers may
        # ignore unknown arguments, which must not silently select another window.
        page = await self.sessions.tools(session_id, owner=owner, name='see')
        for _ in range(16):
            rows = page.get('tools')
            if isinstance(rows, list):
                for row in rows:
                    if not isinstance(row, dict) or row.get('name') != 'see':
                        continue
                    schema = row.get('inputSchema')
                    properties = schema.get('properties') if isinstance(schema, dict) else None
                    window = properties.get('window_id') if isinstance(properties, dict) else None
                    if isinstance(window, dict) and window.get('type') == 'integer':
                        return
                    raise ValueError('Selected MCP server does not support exact-window capture')
            cursor = page.get('nextCursor')
            if not isinstance(cursor, str) or not cursor:
                break
            page = await self.sessions.tools(session_id, owner=owner, name='see', cursor=cursor)
        raise ValueError('Exact-window capture contract unavailable in selected MCP catalog')

    async def observe(self, args: GUIObserve, *, owner: str | None) -> dict[str, JsonValue]:
        if self._interaction.locked():
            raise ValueError('GUI is busy; observe again after the current interaction finishes')
        async with self._interaction:
            return await self._observe(args, owner=owner)

    async def _observe(self, args: GUIObserve, *, owner: str | None) -> dict[str, JsonValue]:
        self.sessions.status(args.session_id, owner=owner)
        self.observations.pop(args.session_id, None)
        capture: dict[str, JsonValue]
        if args.window_id is None:
            focused = normalized(await self.sessions.call(
                args.session_id, 'app', {'action': 'focus', 'name': args.app}, owner=owner,
            ))
            if focused['is_error']:
                return {**focused, 'action_ready': False, 'stage': 'focus'}
            capture = {'app_target': 'frontmost'}
        else:
            await self._require_exact_window(args.session_id, owner)
            capture = {'app_target': args.app, 'window_id': args.window_id}
        raw = await self.sessions.call(
            args.session_id, 'see', capture, owner=owner,
        )
        result = normalized(raw)
        if result['is_error']:
            return result
        content = raw.get('content')
        texts: list[str] = []
        if isinstance(content, list):
            for row in content:
                value = row.get('text') if isinstance(row, dict) else None
                if isinstance(value, str):
                    texts.append(value)
        text = '\n'.join(texts)
        applications = re.findall(r'^Application: (.+)$', text, re.MULTILINE)
        if applications != [args.app]:
            return {**result, 'action_ready': False,
                    'reason': 'observed_application_mismatch'}
        match = re.search(r'^Snapshot ID: ([A-Za-z0-9_-]{1,128})$', text, re.MULTILINE)
        if match is None:
            return {**result, 'action_ready': False, 'reason': 'snapshot_reference_unavailable'}
        snapshot = match[1]
        context: JsonValue = None
        metadata = raw.get('_meta')
        coordinate_status = 'unavailable'
        if isinstance(metadata, dict) and metadata.get('coordinate_context') is not None:
            try:
                parsed = CoordinateContext.model_validate(metadata['coordinate_context'])
                if parsed.reference_id != snapshot:
                    raise ValueError('Snapshot mismatch')
                context = parsed.model_dump(mode='json')
                coordinate_status = 'validated'
            except ValueError:
                coordinate_status = 'unsupported_or_invalid'
        observation = Observation(
            owner, uuid.uuid4().hex, args.app, snapshot,
            frozenset(match[1] for line in text.splitlines()
                      if '[not actionable]' not in line
                      and (match := re.match(r'^\s+([A-Za-z0-9_]+) - ', line))),
            time.monotonic(), args.window_id,
        )
        # Bound history to currently registered sessions; no screenshots are stored here.
        self.observations = {key: value for key, value in self.observations.items()
                             if key in self.sessions.entries and
                             time.monotonic() - value.created < 60}
        self.observations[args.session_id] = observation
        return {**result, 'observation_id': observation.identity, 'app': args.app,
                'window_id': args.window_id,
                'snapshot': snapshot, 'action_ready': True, 'expires_in_seconds': 60,
                'coordinate_context': context, 'coordinate_status': coordinate_status,
                'coordinate_actions_supported': False}

    async def act(self, args: GUIAction, *, owner: str | None) -> dict[str, JsonValue]:
        if self._interaction.locked():
            raise ValueError('GUI is busy; observe again after the current interaction finishes')
        async with self._interaction:
            return await self._act(args, owner=owner)

    async def _act(self, args: GUIAction, *, owner: str | None) -> dict[str, JsonValue]:
        observation = self.observations.get(args.session_id)
        if (observation is None or observation.owner != owner
                or observation.identity != args.observation_id
                or time.monotonic() - observation.created >= 60):
            raise ValueError('GUI observation is missing, stale or belongs to another connection')
        parameters: dict[str, JsonValue]
        if isinstance(args, GUIClick):
            if args.element_id not in observation.elements:
                raise ValueError('Element is not present in the selected observation')
            name, parameters = 'click', {'on': args.element_id, 'snapshot': observation.snapshot}
        elif isinstance(args, GUIType):
            name = 'type'
            if observation.window_id is not None:
                if args.press_return:
                    raise ValueError('Use gui_key after observation for exact-window Return')
                if args.element_id is not None and args.element_id not in observation.elements:
                    raise ValueError('Element is not present in the selected observation')
                parameters = {'text': args.text, 'clear': args.clear,
                              'snapshot': observation.snapshot}
                if args.element_id is not None:
                    parameters['on'] = args.element_id
            else:
                if args.clear or args.element_id is not None:
                    raise ValueError('Replacement and element targeting require exact-window mode')
                parameters = {'text': args.text, 'press_return': args.press_return,
                              'snapshot': observation.snapshot}
        elif isinstance(args, GUIKey):
            aliases = {'esc': 'escape', 'enter': 'return'}
            keys = [aliases.get(key.lower(), key.lower()) for key in args.keys]
            if any(not re.fullmatch(
                r'(?:cmd|shift|alt|option|ctrl|fn|[a-z0-9]|space|return|tab|escape|delete|'
                r'arrow_(?:up|down|left|right)|f(?:[1-9]|1[0-2]))', key,
            ) for key in keys):
                raise ValueError('Unsupported GUI key name; see keys schema for supported names')
            if observation.window_id is None:
                name, parameters = 'hotkey', {'keys': ','.join(keys)}
            else:
                primary = [key for key in keys
                           if key not in {'cmd', 'shift', 'alt', 'option', 'ctrl', 'fn'}]
                if len(primary) != 1:
                    raise ValueError('Exact-window key chord requires one primary key')
                names = {'return': 'Return', 'escape': 'Escape', 'delete': 'BackSpace',
                         'arrow_up': 'Up', 'arrow_down': 'Down', 'arrow_left': 'Left',
                         'arrow_right': 'Right', 'tab': 'Tab'}
                name, parameters = 'press', {'snapshot': observation.snapshot,
                    'keys': ['+'.join(names.get(key, key) for key in keys)]}
        else:
            raise ValueError('Unsupported GUI action')
        # Consume before the first effect. A response failure must not replay input.
        # Keyboard focus is desktop-global, including across provider sessions.
        # Other observations must not survive an input that may change that focus.
        self.observations.clear()
        if observation.window_id is None and name in {'type', 'hotkey'}:
            focused = await self.sessions.call(args.session_id, 'app',
                {'action': 'focus', 'name': observation.app}, owner=owner)
            focus_result = normalized(focused)
            if focus_result['is_error']:
                return {**focus_result, 'input_dispatched': False, 'stage': 'focus'}
        raw = await self.sessions.call(args.session_id, name, parameters, owner=owner)
        return {**normalized(raw), 'observation_consumed': True,
                'app': observation.app, 'stage': 'action_result',
                'window_id': observation.window_id,
                'focus_may_change_externally': observation.window_id is None
                    and name in {'type', 'hotkey'}}
